# Evidencia de Vínculos V3

`validacion.json` registra conteos y huellas de los archivos entregados. `pruebas-node.txt` contiene la salida de 80 pruebas. Las comprobaciones Chromium son 140 generales, 44 nocturnas y 65 V3; sus scripts reproducibles están en `tests/` y se incluyen capturas. No se observaron errores JavaScript ni solicitudes externas.

`simulacion-v3.json` conserva los 120 recorridos completos de 1.080 días por seis aspiraciones. `diagnostico-inicial-v3.json` conserva el ensayo previo al ajuste del mantenimiento; los cambios se explican en `BALANCE_V3_REPORT.md`. `simulacion-consola.txt` contiene la salida de la pasada final.

El piloto usa una política concreta y dificultad equilibrada: no demuestra que todas las decisiones tengan los mismos resultados. Los 32 eventos no observados se enumeran con sus condiciones. Las regresiones dirigidas comprueban migración, crédito, empleo, vivienda, relaciones y ramas nocturnas.
